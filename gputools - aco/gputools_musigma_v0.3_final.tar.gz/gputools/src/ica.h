extern "C" {
	void icainc_JM (float *data_matrix, float *w_matrix, int *nn, int *pp,
		int *ee, float *alpha, int *rowflag, int *colflag, int *funflag,
		int *maxit, float *lim, int *defflag, int *verbose, float *data_pre,
		float *Kmat1, float *w_final, float *ansa, float *ansx2);
}
