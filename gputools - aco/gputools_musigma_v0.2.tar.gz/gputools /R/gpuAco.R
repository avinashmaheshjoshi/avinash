gpuAco <- function(adjMatrix,rho=0.01,alpha=10,beta=7,Q=2,nAnts=5,maxIterations=10000,convergenceNo=500,nThreads = 512,server=NULL){	

	adjMatrix <- as.matrix(adjMatrix)
	dims = dim(adjMatrix)

	if(length(dims) != 2){
		stop("Invalid dimensions of adjMatrix")			
	}
	
	if( dims[1] != dims[2]){
		stop("adjMatrix is not a square matrix")
	}
	
	if(!is.null(server)){
		if (class(server) != "character"){
			server = as.character(server)
		}
	}
	
	distMat_h = matrix(t(adjMatrix))

	nNodes = dims[2]

	bestTour_h = rep(0,(nNodes+1))
	bestGraphLength = 1e5
	elapsedTime = 0
	iterationsRun = 0
	
	if(is.null(server)){
		ret = .C("RgpuAco", as.integer(nNodes),as.single(distMat_h),as.integer(bestTour_h),as.single(bestGraphLength),
			as.single(rho),as.single(alpha),as.single(beta),as.single(Q),as.integer(nAnts),as.integer(maxIterations),as.integer(convergenceNo),as.integer(nThreads),as.single(elapsedTime),as.integer(iterationsRun),PACKAGE='gputools')

		return(list("Optimum_Route" = ret[[3]], "Length_Optimum_route" = ret[[4]], "Time_required" = ret[[13]], "No_Iterations" = ret[[14]]))
	}
	
	else{
		ret = .C("RrpcGpuAco", as.character(server), as.integer(nNodes),as.single(distMat_h),as.integer(bestTour_h),as.single(bestGraphLength),
			as.single(rho),as.single(alpha),as.single(beta),as.single(Q),as.integer(nAnts),as.integer(maxIterations),as.integer(convergenceNo),as.integer(nThreads),as.integer(iterationsRun),PACKAGE='gputools')
		return(list("Optimum_Route" = ret[[4]], "Length_Optimum_route" = ret[[5]], "Time_required" = ret[[13]], "No_Iterations" = ret[[14]]))
	}

	
}


