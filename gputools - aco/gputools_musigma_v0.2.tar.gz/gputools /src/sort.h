void quicksort(int rows, int cols, int colToSortOn, double * array, 
	int left, int right);
