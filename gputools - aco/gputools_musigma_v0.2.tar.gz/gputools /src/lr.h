void logRegression(size_t numParams, size_t numObs, const float * obs, 
	float * outcomes, float * coeffs, float epsilon, float ridge, 
	size_t maxiter);
