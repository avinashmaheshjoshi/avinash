void gpuMatMult(int tpA, int tpB, float * a, int rowsa, int colsa, float * b, int rowsb, 
	int colsb, float * c);
